package com.cognizant.controller.wrapper;

public class SearchExamWrapper {

	private String searchWord;

	public String getSearchWord() {
		return searchWord;
	}

	public void setSearchWord(String searchWord) {
		this.searchWord = searchWord;
	}
}
