package com.cognizant.controller.wrapper;

import org.springframework.stereotype.Component;

@Component
public class GetPassword {
	private String contactNo;
	private String email;
	private String username;

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
